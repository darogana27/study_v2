import json
import boto3
import requests

# S3バケット名は環境変数から取得
BUCKET_NAME = 'twitch-api-data-storage-bucket'

def get_parameter(name):
    """AWS Systems Manager Parameter Storeからパラメータを取得"""
    ssm = boto3.client('ssm')
    response = ssm.get_parameter(
        Name=name,
        WithDecryption=True
    )
    return response['Parameter']['Value']

def get_twitch_token():
    """Twitch APIからアクセストークンを取得"""
    client_id = get_parameter('/twitch/client_id')
    client_secret = get_parameter('/twitch/secret_id')
    
    url = 'https://id.twitch.tv/oauth2/token'
    payload = {
        'client_id': client_id,
        'client_secret': client_secret,
        'grant_type': 'client_credentials'
    }
    response = requests.post(url, data=payload)
    response.raise_for_status()
    return response.json()['access_token']

def get_top_games(token):
    """Twitch APIからトップゲームを取得"""
    client_id = get_parameter('/twitch/client_id')
    
    url = 'https://api.twitch.tv/helix/games/top'
    headers = {
        'Client-ID': client_id,
        'Authorization': f'Bearer {token}'
    }
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    return response.json()

def upload_to_s3(data):
    """取得したデータをS3にアップロード"""
    s3 = boto3.client('s3')
    s3.put_object(Bucket=BUCKET_NAME, Key='top_games.json', Body=json.dumps(data))

def lambda_handler(event, context):
    """Lambda関数のエントリポイント"""
    try:
        token = get_twitch_token()
        top_games = get_top_games(token)
        upload_to_s3(top_games)
        return {
            'statusCode': 200,
            'body': json.dumps('Top games data collected successfully!')
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': str(e)
        }
