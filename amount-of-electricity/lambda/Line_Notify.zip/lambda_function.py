import json
import boto3
import datetime
import urllib.request

# 定数をトップレベルで定義
API_URL = 'https://notify-api.line.me/api/notify'
BUCKET_NAME = 'amount-of-electricity'
TOKEN_PARAM_NAME = 'Line_Access_Token'

def lambda_handler(event, context):
    # S3クライアントとSSMクライアントを作成
    s3 = boto3.client('s3')
    ssm = boto3.client('ssm')
    
    # LINE Notifyのアクセストークンを取得
    try:
        response = ssm.get_parameter(Name=TOKEN_PARAM_NAME, WithDecryption=True)
        TOKEN = response['Parameter']['Value']
    except ssm.exceptions.ParameterNotFound:
        return {
            'statusCode': 500,
            'body': 'LINE Notify token not found in Parameter Store'
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': str(e)
        }

    # 前日の日付を取得
    yesterday = datetime.datetime.now() - datetime.timedelta(days=1)
    year = str(yesterday.year)
    month = str(yesterday.month).zfill(2)
    day = str(yesterday.day).zfill(2)
    weekday_jp = ["日", "月", "火", "水", "木", "金", "土"][int(yesterday.strftime("%w"))]
    object_key = f'{year}/{month}/{day}.txt'

    try:
        response = s3.get_object(Bucket=BUCKET_NAME, Key=object_key)
        file_content = response['Body'].read().decode('utf-8')

        # kWhの数値を取得しコメントを作成
        kWh_value = float(''.join(filter(str.isdigit, file_content))) / 10
        if kWh_value <= 5:
            comment = "この調子です！\nこのまま節電を意識しましょう！"
        elif kWh_value <= 15:
            comment = "使いすぎではないですが\n節約を意識しましょう！"
        else:
            comment = "使いすぎじゃい！\n気を付けぃ！"

        # 送信するメッセージを作成
        message = f"\n{month}/{day}({weekday_jp})の電気使用量は\n{file_content}です\n\n{comment}"
        
        # LINE Notifyに送信
        send_line_notify(API_URL, TOKEN, message)

        return {
            'statusCode': 200,
            'body': 'Message sent successfully'
        }
    except s3.exceptions.NoSuchKey:
        return {
            'statusCode': 404,
            'body': 'The specified key does not exist in the bucket'
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': str(e)
        }

def send_line_notify(api_url, token, message):
    request_headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Bearer ' + token
    }
    params = {'message': message}
    data = urllib.parse.urlencode(params).encode('ascii')
    req = urllib.request.Request(api_url, headers=request_headers, data=data, method='POST')
    try:
        urllib.request.urlopen(req)
    except urllib.error.URLError as e:
        raise RuntimeError(f'Failed to send LINE Notify message: {e.reason}')
